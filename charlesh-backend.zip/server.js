require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const nodemailer = require('nodemailer');
const { Client, Environment } = require('square');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const client = new Client({
  accessToken: process.env.SQUARE_ACCESS_TOKEN,
  environment: Environment.Production
});

const paymentsApi = client.paymentsApi;

app.post('/process-payment', async (req, res) => {
  const { token, amount } = req.body;

  try {
    const result = await paymentsApi.createPayment({
      sourceId: token,
      idempotencyKey: crypto.randomUUID(),
      amountMoney: {
        amount: Math.round(amount * 100),
        currency: 'USD',
      },
    });

    const orderDetails = {
      amount,
      timestamp: new Date().toISOString()
    };

    // Send confirmation email
    const transporter = nodemailer.createTransport({
      host: "smtp.networksolutions.com",
      port: 465,
      secure: true,
      auth: {
        user: "office@charleshallinc.com",
        pass: "Weatherman305$"
      }
    });

    await transporter.sendMail({
      from: '"Charles Hall Inc." <office@charleshallinc.com>',
      to: "office@charleshallinc.com",
      subject: "New Order Confirmation",
      text: `New payment received. Amount: $${amount}`,
    });

    res.json({ success: true, payment: result.result.payment });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get("/", (req, res) => {
  res.send("Charles Hall Inc. Payment Backend is Live");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));